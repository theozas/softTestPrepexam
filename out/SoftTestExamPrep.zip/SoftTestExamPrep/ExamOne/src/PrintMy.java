public interface PrintMy {
    public String toString();
}
